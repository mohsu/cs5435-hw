from sqlalchemy import Column, Integer, String

from app.models.base import Base

import app.util

class User(Base):
    __tablename__ = "users"

    

    username = Column(String, primary_key=True)
    # password = Column(String)
    salted_password = Column(String)
    salt = Column(String)
    coins = Column(Integer)

    

    def get_coins(self):
        return self.coins

    def credit_coins(self, i):
        self.coins += i

    def debit_coins(self, i):
        self.coins -= i

def create_user(db, username, password):
    salt = app.util.hash.random_salt()
    salted_password = app.util.hash.hash_pbkdf2(password, salt)
    user = User(
        username=username,
        salted_password=salted_password,
        salt = salt,
        coins=100,
    )
    print(f"username:{username}, password:{password}, salt:{salt}, salted_password:{salted_password}")
    print(user.salted_password)
    db.add(user)
    return user

def get_user(db, username):
    return db.query(User).filter_by(username=username).first()


