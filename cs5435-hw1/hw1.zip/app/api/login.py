from bottle import (
    get,
    post,
    redirect,
    request,
    response,
    jinja2_template as template,
)

from app.models.user import create_user, get_user
from app.models.session import (
    delete_session,
    create_session,
    get_session_by_username,
    logged_in,
)
from app.scripts.breaches import load_breaches
from app.models.breaches import get_breaches
import app.util


@get('/login')
def login():
    return template('login')

@post('/login')
def do_login(db):
    def exit():
        if error is None:  # Perform login
            existing_session = get_session_by_username(db, username)
            if existing_session is not None:
                delete_session(db, existing_session)
            session = create_session(db, username)
            response.set_cookie("session", str(session.get_id()))
            return redirect("/{}".format(username))
        return template("login", error=error)
    
    def do_create():
        if user is not None:
            response.status = 401
            error = "{} is already taken.".format(username)
        else:
            create_user(db, username, password)

    username = request.forms.get('username')
    password = request.forms.get('password')
    error = None
    user = get_user(db, username)
    print(user)
    
    load_breaches(db)
    if (request.forms.get("login")):
        if user is None:
            response.status = 401
            error = "{} is not registered.".format(username)
        else:
            salt = user.salt
            to_salted_password = app.util.hash.hash_pbkdf2(password, salt)
            if user.salted_password != to_salted_password:
            # elif user.password != password:
                response.status = 401
                error = "Wrong password for {}.".format(username)
            else:
                pass  # Successful login
    elif (request.forms.get("register")):

        plaintext_breaches, hashed_breaches, salted_breaches = get_breaches(db, username)
        print(plaintext_breaches, hashed_breaches, salted_breaches)
        if not plaintext_breaches:
            pass
        else:
            response.status = 401
            error = f"{username}, {plaintext_breaches[0].password} is plaintext breached."
            return exit()
        # print(plaintext_breaches[1].username)
        if not hashed_breaches:
            pass
        else:
            hashed = hashed_breaches[0].hashed_password
            if hashed==app.util.hash_sha256(password):
                response.status = 401
                error = f"{username}, {password} is hash breached."
                return exit()
            else:
                pass
        if not salted_breaches:
            pass
        else:
            pbkdf2_salted_password = salted_breaches[0].salted_password
            salt = salted_breaches[0].salt
            if pbkdf2_salted_password==app.util.hash.hash_pbkdf2(password, salt):
                response.status = 401
                error = f"{username}, {password} is salt breached."
                print(pbkdf2_salted_password, app.util.hash.hash_pbkdf2(password, salt), salt)
                return exit()
            else:
                pass
        
        do_create()
        
    else:
        response.status = 400
        error = "Submission error."
    # def exit():
    #     if error is None:  # Perform login
    #         existing_session = get_session_by_username(db, username)
    #         if existing_session is not None:
    #             delete_session(db, existing_session)
    #         session = create_session(db, username)
    #         response.set_cookie("session", str(session.get_id()))
    #         return redirect("/{}".format(username))
    #     return template("login", error=error)
    print('fffffff')
    
    return exit()

@post('/logout')
@logged_in
def do_logout(db, session):
    delete_session(db, session)
    response.delete_cookie("session")
    return redirect("/login")


