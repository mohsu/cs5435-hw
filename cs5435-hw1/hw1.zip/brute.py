from csv import reader
import app.util

COMMON_PASSWORDS_PATH = 'common_passwords.txt'
SALTED_BREACH_PATH = "app/scripts/breaches/salted_breach.csv"

def load_breach(fp):
    with open(fp) as f:
        r = reader(f, delimiter=' ')
        header = next(r)
        assert(header[0] == 'username')
        return list(r)

def load_common_passwords():
    with open(COMMON_PASSWORDS_PATH) as f:
        pws = list(reader(f))
    return pws

def brute_force_attack(target_hash, target_salt):
#     print(target_hash, target_salt)
    pws = load_common_passwords()
#     print(pws)
    our_app_iters = 100000  

    for password in pws:
#         print(password)
        salted = app.util.hash.hash_pbkdf2(password[0], target_salt)
#         dk = pbkdf2_hmac('sha256', password[0].encode('utf_8'), target_salt.encode('utf_8'), our_app_iters)
#         salted = dk.hex()
#         print(len(salted), len(target_hash))
#         print(salted,target_hash)
        if salted==target_hash:
            return password
    return None

def main():
    salted_creds = load_breach(SALTED_BREACH_PATH)
#     print(salted_creds[0])
#     return
    for i in range(len(salted_creds)):
        print(i)
        guess_pwd = brute_force_attack(salted_creds[i][1], salted_creds[i][2])
        if guess_pwd:
            print(f'{guess_pwd}, ans:{salted_creds[i][0]}')

if __name__ == "__main__":
    main()